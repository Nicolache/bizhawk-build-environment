﻿namespace BizHawk.Client.EmuHawk
{
	partial class AboutBox
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.mom2 = new System.Windows.Forms.PictureBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.mom1 = new System.Windows.Forms.PictureBox();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.CloseBtn = new System.Windows.Forms.Button();
			this.btnBizBox = new System.Windows.Forms.Button();
			this.tbBranch = new System.Windows.Forms.TextBox();
			this.tbCommit = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.pictureBox5 = new BizHawk.Client.EmuHawk.MyViewportPanel();
			this.HR = new BizHawk.Client.EmuHawk.HorizontalLine();
			((System.ComponentModel.ISupportInitialize)(this.mom2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.mom1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(0, -3);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(490, 108);
			this.label1.TabIndex = 1;
			this.label1.Text = "BIZHAWK";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(12, 311);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(291, 165);
			this.label2.TabIndex = 2;
			this.label2.Text = "EMULATES\r\nY̶̷̼̬̟̘̦̼͙̝̯̦̠̜͙͖̘ͨ̒͂͐ͪ͂̒̄ͯͯ͌ͨͯ̽ͨ́͝ͅO̡̝̞̗̩͖͖̼̹̖̫͍̙̖͓̩ͪ͂̊ͭ͑ͮͤ̀̄͌̑ͨͣͩ̿ͫ͂͟͝͞ͅU̴̮̝͍̜̰̦ͥ̓ͩ̌̎̾ͥͪ̋̾́͠Rͨ͊̉̾҉̢̫͔̗͓͖̫̫̘̖̰͟\r\nMOM";
			// 
			// timer1
			// 
			this.timer1.Enabled = true;
			this.timer1.Interval = 50;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(164, 423);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(311, 39);
			this.label3.TabIndex = 3;
			this.label3.Text = "COPYRITE 20011";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(338, 223);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(175, 48);
			this.label4.TabIndex = 5;
			this.label4.Text = "(LEVAR BURTON\r\nCAMEO)";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(222, 369);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(104, 55);
			this.label5.TabIndex = 8;
			this.label5.Text = "--->";
			// 
			// mom2
			// 
			this.mom2.Image = global::BizHawk.Client.EmuHawk.Properties.Resources.mom2.Value;
			this.mom2.Location = new System.Drawing.Point(372, 274);
			this.mom2.Name = "mom2";
			this.mom2.Size = new System.Drawing.Size(115, 150);
			this.mom2.TabIndex = 6;
			this.mom2.TabStop = false;
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = global::BizHawk.Client.EmuHawk.Properties.Resources.pictureBox2.Value;
			this.pictureBox2.Location = new System.Drawing.Point(353, 97);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(122, 108);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox2.TabIndex = 9;
			this.pictureBox2.TabStop = false;
			// 
			// mom1
			// 
			this.mom1.Image = global::BizHawk.Client.EmuHawk.Properties.Resources.mom1.Value;
			this.mom1.Location = new System.Drawing.Point(372, 274);
			this.mom1.Name = "mom1";
			this.mom1.Size = new System.Drawing.Size(115, 150);
			this.mom1.TabIndex = 7;
			this.mom1.TabStop = false;
			this.mom1.Visible = false;
			// 
			// pictureBox4
			// 
			this.pictureBox4.Image = global::BizHawk.Client.EmuHawk.Properties.Resources.pictureBox4.Value;
			this.pictureBox4.Location = new System.Drawing.Point(21, 89);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Size = new System.Drawing.Size(128, 128);
			this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox4.TabIndex = 16;
			this.pictureBox4.TabStop = false;
			// 
			// pictureBox3
			// 
			this.pictureBox3.Image = global::BizHawk.Client.EmuHawk.Properties.Resources.pictureBox3.Value;
			this.pictureBox3.Location = new System.Drawing.Point(21, 89);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new System.Drawing.Size(128, 128);
			this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pictureBox3.TabIndex = 17;
			this.pictureBox3.TabStop = false;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = global::BizHawk.Client.EmuHawk.Properties.Resources.pictureBox1.Value;
			this.pictureBox1.Location = new System.Drawing.Point(155, 108);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(171, 216);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// CloseBtn
			// 
			this.CloseBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.CloseBtn.Location = new System.Drawing.Point(424, 462);
			this.CloseBtn.Name = "CloseBtn";
			this.CloseBtn.Size = new System.Drawing.Size(75, 23);
			this.CloseBtn.TabIndex = 18;
			this.CloseBtn.Text = "&Close";
			this.CloseBtn.UseVisualStyleBackColor = true;
			this.CloseBtn.Click += new System.EventHandler(this.Close_Click);
			this.CloseBtn.MouseEnter += new System.EventHandler(this.Close_MouseEnter);
			// 
			// btnBizBox
			// 
			this.btnBizBox.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnBizBox.Location = new System.Drawing.Point(-4, -3);
			this.btnBizBox.Name = "btnBizBox";
			this.btnBizBox.Size = new System.Drawing.Size(75, 23);
			this.btnBizBox.TabIndex = 19;
			this.btnBizBox.Text = "BizBox";
			this.btnBizBox.UseVisualStyleBackColor = true;
			this.btnBizBox.Click += new System.EventHandler(this.btnBizBox_Click);
			// 
			// tbBranch
			// 
			this.tbBranch.Location = new System.Drawing.Point(49, 476);
			this.tbBranch.Name = "tbBranch";
			this.tbBranch.ReadOnly = true;
			this.tbBranch.Size = new System.Drawing.Size(100, 20);
			this.tbBranch.TabIndex = 20;
			// 
			// tbCommit
			// 
			this.tbCommit.Location = new System.Drawing.Point(203, 476);
			this.tbCommit.Name = "tbCommit";
			this.tbCommit.ReadOnly = true;
			this.tbCommit.Size = new System.Drawing.Size(100, 20);
			this.tbCommit.TabIndex = 20;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(2, 479);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(44, 13);
			this.label6.TabIndex = 21;
			this.label6.Text = "Branch:";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(155, 479);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(44, 13);
			this.label7.TabIndex = 22;
			this.label7.Text = "Commit:";
			// 
			// pictureBox5
			// 
			this.pictureBox5.Enabled = false;
			this.pictureBox5.Location = new System.Drawing.Point(71, 223);
			this.pictureBox5.Name = "pictureBox5";
			this.pictureBox5.Size = new System.Drawing.Size(376, 48);
			this.pictureBox5.TabIndex = 15;
			this.pictureBox5.TabStop = false;
			// 
			// HR
			// 
			this.HR.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.HR.Location = new System.Drawing.Point(349, 213);
			this.HR.Name = "HR";
			this.HR.Size = new System.Drawing.Size(158, 2);
			this.HR.TabIndex = 4;
			this.HR.Text = "COPYRITE 2001";
			// 
			// AboutBox
			// 
			this.AcceptButton = this.CloseBtn;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.CloseBtn;
			this.ClientSize = new System.Drawing.Size(519, 497);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.tbCommit);
			this.Controls.Add(this.tbBranch);
			this.Controls.Add(this.btnBizBox);
			this.Controls.Add(this.CloseBtn);
			this.Controls.Add(this.pictureBox5);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.pictureBox3);
			this.Controls.Add(this.pictureBox4);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.mom1);
			this.Controls.Add(this.mom2);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.HR);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.DoubleBuffered = true;
			this.Icon = global::BizHawk.Client.EmuHawk.Properties.Resources.logo;
			this.MaximizeBox = false;
			this.MaximumSize = new System.Drawing.Size(527, 524);
			this.MinimumSize = new System.Drawing.Size(527, 524);
			this.Name = "AboutBox";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "EmuHawk Interim Build";
			this.Load += new System.EventHandler(this.AboutBox_Load);
			((System.ComponentModel.ISupportInitialize)(this.mom2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.mom1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Timer timer1;
		private System.Windows.Forms.Label label3;
		private HorizontalLine HR;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.PictureBox mom2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.PictureBox mom1;
		private MyViewportPanel pictureBox5;
		private System.Windows.Forms.PictureBox pictureBox4;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button CloseBtn;
		private System.Windows.Forms.Button btnBizBox;
		private System.Windows.Forms.TextBox tbBranch;
		private System.Windows.Forms.TextBox tbCommit;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
	}
}