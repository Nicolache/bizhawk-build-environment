﻿namespace BizHawk.Client.EmuHawk
{
	/// <summary>
	/// toolform that takes automatic common configuration infrastructure
	/// </summary>
	public interface IToolFormAutoConfig : IToolForm
	{
	}
}
