﻿namespace BizHawk.Client.Common
{
	public enum PreviousType
	{
		Original = 0,
		LastSearch = 1,
		LastFrame = 2,
		LastChange = 3
	}
}
